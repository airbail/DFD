## Terms and Conditions of LAV-DF

The users should agree to the terms and conditions to use the LAV-DF dataset. In exchange for such permission, the users hereby agree to the following terms and conditions:

- The dataset can only be used for non-commercial research and educational purposes.
- You understand that the LAV-DF dataset is a deepfake dataset generated based on Voxceleb2. You also agree to all agreements of the VoxCeleb2 dataset.
- The authors of the dataset make no representations or warranties regarding the dataset, including but not limited to warranties of non-infringement or fitness for a particular purpose.
- You accept full responsibility for your use of the dataset and shall defend and indemnify the Authors of LAV-DF, against any and all claims arising from your use of the dataset, including but not limited to your use of any copies of copyrighted images that you may create from the dataset.
